// 一次性脚本（不入库）：列出最近 runs 的 job / step 失败详情。
import https from 'node:https'

const token = process.env.GH_TOKEN
const repo = 'jick-nice/dsh-purge-community-go'

function get(path, raw = false) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        host: 'api.github.com',
        path,
        method: 'GET',
        family: 4,
        timeout: 30000,
        headers: {
          Authorization: `token ${token}`,
          Accept: raw ? 'application/vnd.github+json' : 'application/vnd.github+json',
          'User-Agent': 'dsh-purge-community-go-check',
        },
      },
      (res) => {
        let data = ''
        res.on('data', (c) => {
          data += c
        })
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, json: JSON.parse(data) })
          } catch {
            resolve({ status: res.statusCode, raw: data.slice(0, 500) })
          }
        })
      },
    )
    req.on('timeout', () => reject(new Error('timeout')))
    req.on('error', reject)
    req.end()
  })
}

const runs = await get(`/repos/${repo}/actions/runs?per_page=3`)
for (const run of runs.json.workflow_runs || []) {
  console.log(`\n=== ${run.name} #${run.run_number} ${run.status}/${run.conclusion}`)
  const jobs = await get(`/repos/${repo}/actions/runs/${run.id}/jobs`)
  for (const job of jobs.json.jobs || []) {
    console.log(`  job: ${job.name} ${job.status}/${job.conclusion}`)
    for (const step of job.steps || []) {
      const mark = step.conclusion === 'failure' ? 'FAIL' : step.conclusion || '-'
      if (mark === 'FAIL') console.log(`    ${step.number}. ${step.name} -> ${step.conclusion}`)
    }
  }
}
