// 一次性脚本（不入库）：检查仓库、workflow 运行、Release 状态。
import https from 'node:https'

const token = process.env.GH_TOKEN
const repo = 'jick-nice/dsh-purge-community-go'

function get(path) {
  return new Promise((resolve, reject) => {
    const req = https.request(
      {
        host: 'api.github.com',
        path,
        method: 'GET',
        family: 4,
        timeout: 30000,
        headers: {
          Authorization: `token ${token}`,
          Accept: 'application/vnd.github+json',
          'User-Agent': 'dsh-purge-community-go-check',
        },
      },
      (res) => {
        let data = ''
        res.on('data', (c) => {
          data += c
        })
        res.on('end', () => {
          try {
            resolve({ status: res.statusCode, json: JSON.parse(data) })
          } catch {
            resolve({ status: res.statusCode, json: null, raw: data.slice(0, 200) })
          }
        })
      },
    )
    req.on('timeout', () => reject(new Error('timeout')))
    req.on('error', reject)
    req.end()
  })
}

const info = await get(`/repos/${repo}`)
if (info.status === 200) {
  const r = info.json
  console.log(`repo: ${r.full_name} vis=${r.visibility} default=${r.default_branch} size=${r.size}KB`)
  console.log(`topics: ${(r.topics || []).join(',') || '(none)'} license=${r.license?.spdx_id || '(none)'}`)
} else {
  console.log('repo check failed', info.status, info.raw)
}

const commits = await get(`/repos/${repo}/commits?per_page=5`)
if (commits.status === 200 && Array.isArray(commits.json)) {
  console.log(`commits: ${commits.json.length}`)
  for (const c of commits.json) console.log(`  ${c.sha.slice(0, 7)} ${c.commit.message.split('\n')[0]}`)
}

const runs = await get(`/repos/${repo}/actions/runs?per_page=5`)
if (runs.status === 200) {
  const list = runs.json.workflow_runs || []
  console.log(`runs: ${list.length}`)
  for (const run of list) {
    console.log(`  ${run.name} #${run.run_number} ${run.status}/${run.conclusion || '-'} event=${run.event} ${run.html_url}`)
  }
} else {
  console.log('runs check failed', runs.status, runs.raw)
}

const rel = await get(`/repos/${repo}/releases`)
if (rel.status === 200) {
  const list = Array.isArray(rel.json) ? rel.json : []
  console.log(`releases: ${list.length}`)
  for (const r of list) {
    const assets = (r.assets || []).map((a) => `${a.name}(${Math.round(a.size / 1024)}KB)`).join(', ')
    console.log(`  ${r.tag_name} draft=${r.draft} prerelease=${r.prerelease} assets=[${assets}]`)
  }
} else {
  console.log('releases check failed', rel.status, rel.raw)
}
