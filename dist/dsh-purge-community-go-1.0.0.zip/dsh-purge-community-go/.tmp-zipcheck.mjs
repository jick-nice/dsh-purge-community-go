// 一次性脚本（不入库）：下载 release 的 zip 并用 bsdtar 列出条目，确认没有把 dist/.git 打进去。
import fs from 'node:fs'
import https from 'node:https'
import os from 'node:os'
import path from 'node:path'
import { spawnSync } from 'node:child_process'

const url =
  'https://github.com/jick-nice/dsh-purge-community-go/releases/download/v1.0.0/dsh-purge-community-go-1.0.0.zip'
const dest = path.join(os.tmpdir(), 'pg-release.zip')

function download(u, out, hops = 0) {
  return new Promise((resolve, reject) => {
    if (hops > 5) return reject(new Error('too many redirects'))
    https
      .get(u, { family: 4, timeout: 60000 }, (res) => {
        if (res.statusCode === 302 || res.statusCode === 301 || res.statusCode === 307) {
          res.resume()
          return resolve(download(res.headers.location, out, hops + 1))
        }
        if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`))
        const file = fs.createWriteStream(out)
        res.pipe(file)
        file.on('finish', () => file.close(() => resolve(out)))
      })
      .on('error', reject)
  })
}

await download(url, dest)
console.log('downloaded', (fs.statSync(dest).size / 1024).toFixed(1), 'KB')

// bsdtar 能直接读 zip；GNU tar 不能，所以用 Windows 自带的 tar.exe。
const list = spawnSync('tar', ['-tf', dest], { encoding: 'utf8', maxBuffer: 32 * 1024 * 1024 })
if (list.status !== 0) {
  console.error('tar -tf failed', list.stderr)
  process.exit(1)
}
const entries = list.stdout.split('\n').filter(Boolean)
console.log('entries', entries.length)
const bad = entries.filter((e) => e.includes('/dist/') || e.includes('/.git/') || e.includes('node_modules'))
console.log('suspicious entries:', bad.length)
for (const e of bad.slice(0, 10)) console.log('  !', e)
console.log('top-level dirs:', [...new Set(entries.map((e) => e.split('/')[0]))].join(','))
